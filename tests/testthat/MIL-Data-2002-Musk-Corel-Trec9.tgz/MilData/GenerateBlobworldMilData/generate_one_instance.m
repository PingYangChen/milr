%
% inst = generate_one_instance(bag_index, instance_index, label, X)
%
function inst = generate_one_instance(i, j, label, X)
%
% By Stuart Andrews (stu@cs.brown.edu)
% Brown University, Providence, RI
% Last modified: August 2003
%
inst    = [i, j, label, X(:)']';

%inst(1:10)

%inst.i          = i;                    % image number
%inst.j          = j;                    % segment number
%inst.label      = label;                % label
%inst.X          = X;

return;
%%%%%%%%%%%%



