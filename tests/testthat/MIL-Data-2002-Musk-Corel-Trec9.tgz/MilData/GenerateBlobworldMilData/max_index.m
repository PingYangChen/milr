% max_i = max_index(positive_bag_set)
%

function max_i = max_index(bag_set)
%
% By Stuart Andrews (stu@cs.brown.edu)
% Brown University, Providence, RI
% Last modified: August 2003
%
max_i = bag_set(1, end);
%max_i = bag_set(end).i
return;
%%%%%%%%%%%%


