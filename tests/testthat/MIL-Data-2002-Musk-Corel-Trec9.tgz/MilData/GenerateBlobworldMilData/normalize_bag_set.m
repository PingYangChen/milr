%
% bag_set = normalize_bag_set(bag_set)
%
function bag_set = normalize_bag_set(bag_set)
%
% By Stuart Andrews (stu@cs.brown.edu)
% Brown University, Providence, RI
% Last modified: August 2003
%

Nbag        = size(bag_set, 2);


% unpack bag data
Z           = bag_set(4:end,:);
Z           = Z';

% center
uu          = mean(Z);
Z           = Z - repmat(uu, Nbag, 1);

% normalize by variance
vv          = std(Z);
Inzz        = find(vv~=0);

if (~isempty(Inzz))
    Z(:,Inzz)   = Z(:,Inzz)./repmat(vv(Inzz), Nbag, 1);
end


%%% debugging
%%debug(3,:)          = var(Z);
%%format long
%%debug               = debug'
%%%%


% repack bag data
Z           = Z';
bag_set(4:end,:) = Z;


return;
%%%%%%%%%%%%



