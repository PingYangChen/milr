%
% success = write_bag_set(mil_bag_set_filename, bag_set)
%
%   Renumber instances and bags starting from zero.  Feature indices start at
%   one.  <inst_id>:<bag_id>:<label>.   
%   EG:
%
%   0:0:1 1:<val> 2:<val>
%   1:0:1 1:<val> 2:<val>
%   .
%   .
%   .
%   13:1:1 1:<val> 2:<val>
%   14:1:1 1:<val> 2:<val>
%   .
%   .
%   130:17:-1 18908:<val> 20000:<val>
%   149:17:-1 1000 <val> 20000:<val>
%
function success = write_bag_set(filename, bag_set, comment)
%
% By Stuart Andrews (stu@cs.brown.edu)
% Brown University, Providence, RI
% Last modified: August 2003
%

start_feature_index     = 1;

Ninst = size(bag_set, 2);
maxBagSize = [Ninst, Ninst];

success = 0;
fid = fopen(filename, 'w');
if ( fid < 0 )
    disp( 'could not open file' );
    disp( ['Failed to write _bags_ to ', filename] );
    return;
end


fprintf(fid, '# %s\n', comment);

numPosBags = 0;
numNegBags = 0;
curr_I_bag = -1;
curr_I_bag_print = -1;
curr_I_inst_print = -1;
for i = 1:size(bag_set, 2) 

    % --> print bag_index (shifted by offset), and label
    %fprintf(fid, '%d:%d', bag_set(1,i) - mil_bag_index_offset, bag_set(3,i)); 
    I_inst    = bag_set(2,i);
    I_bag     = bag_set(1,i);
    bag_label = bag_set(3,i); 

    %%fprintf(fid, '%d:%d:%d', I_inst, I_bag, bag_label);
    %--- renumbering
    prnt = 1;
    if (I_bag > curr_I_bag)
        if (bag_label==1) 
            if (numPosBags < maxBagSize(1))
                curr_I_bag = I_bag;
                numPosBags = numPosBags+1;
                curr_I_bag_print = curr_I_bag_print+1;
            else
                prnt = 0;
            end
        end
        if (bag_label==-1) 
            if (numNegBags < maxBagSize(2))
                curr_I_bag = I_bag;
                numNegBags = numNegBags+1;
                curr_I_bag_print = curr_I_bag_print+1;
            else
                prnt = 0;
            end
        end
    elseif (I_bag < curr_I_bag)
        disp('Warning : bags ids decreasing ... will continue anyway.');
    end

    if (prnt)
        curr_I_inst_print = curr_I_inst_print+1;
        %--- print baginfo
        fprintf(fid, '%d:%d:%d', curr_I_inst_print, curr_I_bag_print, bag_label);
        %--- features and feature indices 
        gg      = bag_set(4:end, i);
        ii      = ((1:length(gg)) - 1) + start_feature_index; 
        ii      = ii(:);
        inzz    = 1:length(gg);  %% use this to print all features, regardless
        gg      = [ii(inzz), gg(inzz)]';
        fprintf(fid, ' %d:%f', gg);
        fprintf(fid, '\n');
    end
end
fclose(fid);
success = 1;
disp(['Wrote mil file (', filename, ') with ', num2str(Ninst), ' instances.']);

return;




